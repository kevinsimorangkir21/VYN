<div align="center">
<h1> Portofolio</h1>

[![Github Commit](https://img.shields.io/github/commit-activity/m/kevinsimorangkir21/VYN)](#)
[![Github Contributors](https://img.shields.io/badge/all_contributors-1-orange.svg)](#)
</div>

## **Description**
This portfolio was created to provide information to people about myself regarding skills, origins, or identity. The description will be updated regularly and included in it.

<!-- ## **Fitur Utama Aplikasi** :
<!-- - Home : Tampilan awal menampilkan deskripsi singkat tentang diri
- About : Menampilkan identitas diri saya yang dimulai dari umur dll
- Education : Menampilkan riwayat pendidikan
- Experience : Menampilkan riwayat pengalaman
- Contact : Menampilkan nomor telepon, email, dan alamat diri --> 
